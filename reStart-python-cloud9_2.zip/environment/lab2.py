"""
Your module description
"""
print("Python has three numberic types: int,float, and complex")